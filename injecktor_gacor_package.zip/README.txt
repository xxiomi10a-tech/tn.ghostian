Files in this package:
- index.html    (the webpage)
- logo.png      (optional: replace with your TN.Ghostian logo)
- qris.png      (optional: replace with your QRIS image)

Notes:
- This is a frontend-only package. The "Kirim Bukti (Simulasi)" button does not upload to a server.
- Replace logo.png and qris.png with your actual images (use same filenames), then open index.html in a browser.
